

v 0.2.3 - Bugs fixed and video included

v 0.2.2 - Priors selection improved, variable names added to the tables and model, survey wizard, serial designs improved

v 0.1.1 - Now priors can be introduced manually.

v 0.0.1 - Release